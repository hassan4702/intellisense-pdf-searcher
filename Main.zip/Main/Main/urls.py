
from django.contrib import admin
from django.urls import path,include
from home import views
from django.conf import settings
from django.conf.urls.static import static
from django.conf.urls import  url
from django.views.static import serve



urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.index,name='home'),
    path('home',views.home,name='home'),
    path('contact',views.contact,name='contact'),
    path('login',views.loginuser,name='login'),
    path('logout',views.logoutuser,name='logout'),
    path('about',views.about,name='about'),
    path('contactus',views.contactus,name='contactus'),
    path('search',views.search,name='search'),
    path('signup', views.signup, name='signup'),
    # path('',views.search),
    # url(r'^download/(?P<path>.*)$',serve,{'document_root':settings.MEDIA_ROOT}),


]
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
