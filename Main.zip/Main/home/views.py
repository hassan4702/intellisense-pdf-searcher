from django.shortcuts import render,redirect,HttpResponse,Http404
from django.contrib.auth.models import User
from django.contrib.auth import logout, authenticate, login
from django.contrib.auth.forms import UserCreationForm
from django.views import generic
from datetime import datetime
from home.models import Contact
from home.models import Fileadmin
from django.contrib import messages
import os
import io
import Main.settings as settings
from django.http import FileResponse
from reportlab.pdfgen import canvas
def home(request):
    print(request.user)
    if request.user.is_anonymous:
        return redirect("/login") 
    return render(request,'home.html')
def loginuser(request):
    if request.method=="POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        print(username, password)
        user = authenticate(username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect("/")

        else:
            return render(request, 'login.html')



    return render(request,'login.html')
def logoutuser(request):
    logout(request)
    return redirect("/login")
def about(request):
    print(request.user)
    if request.user.is_anonymous:
        return redirect("/login") 
    return render(request,'about.html')
def index(request):
    print(request.user)
    if request.user.is_anonymous:
        return redirect("/login") 
    return render(request,'home.html')
def contact(request):
    print(request.user)
    if request.user.is_anonymous:
        return redirect("/login")
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contact = Contact(name=name, email=email, phone=phone, desc=desc, date = datetime.today())
        contact.save()
        messages.success(request, 'Your message has been sent!')
    return render(request, 'contact.html')
def contactus(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        desc = request.POST.get('desc')
        contact = Contact(name=name, email=email, phone=phone, desc=desc, date = datetime.today())
        contact.save()
    return render(request,'contactus.html')
    
def signup(request):
    return render(request,'signup.html')
def about(request):
    contaxt={'file':Fileadmin.objects.all()}
    return render(request,'about.html',contaxt)

def search(request):
    quary1=str("asd")
    quary1=request.GET['quary']
    quary=quary1[:-1]
    allFileadmins=Fileadmin.objects.filter(title__icontains=quary)
    params={'allFileadmins':allFileadmins}
    return render(request,'search.html',params)
    
def download(request,path):
    file_path=os.path.join(settings.MEDIA_ROOT,path)
    if os.path.exists(file_path):
        with open(file_path,'rb')as fh:
            response=HttpResponse(fh.read(),content_type="appliction/adminupload")
            response['Content-Disposition']='inline;filename='+os.path.basename(file_path)
            fh.save()
            return response
    raise Http404
def signup(request):
    if request.method=="POST":
        username=request.POST['username']
        email=request.POST['email']
        fname=request.POST['fname']
        lname=request.POST['lname']
        password=request.POST['password']
        password2=request.POST['password2']
        myuser = User.objects.create_user(username, email, password)
        myuser.first_name= fname
        myuser.last_name= lname
        myuser.save()
        return redirect('/home')
    return render(request,'signup.html')